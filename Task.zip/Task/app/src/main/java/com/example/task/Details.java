package com.example.task;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class Details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);
        TextView C = (TextView) findViewById(R.id.textView8);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int value = extras.getInt("id");

            String[] wood = {"ash","birch","cedar","cherrywood","fir","mahogany","maple","oak","poplar","redwood"};

            switch (value){

                case 0:
                    C.setText(R.string.ash);
                    break;

                case 1:
                    C.setText(R.string.birch);
                    break;

                case 2:
                    C.setText(R.string.cedar);
                    break;

                case 3:
                    C.setText(R.string.cherrywood);
                    break;

                case 4:
                    C.setText(R.string.fir);
                    break;

                case 5:
                    C.setText(R.string.mahogany);
                    break;

                case 6:
                    C.setText(R.string.maple);
                    break;

                case 7:
                    C.setText(R.string.oak);
                    break;

                case 8:
                    C.setText(R.string.poplar);
                    break;
                case 9:
                    C.setText(R.string.redwood);
                    break;

                default:
                    break;
            }

        }






    }
}
