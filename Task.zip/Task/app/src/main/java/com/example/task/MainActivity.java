package com.example.task;



import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] res_id = new int[10];
        String[]DrawableName = new String[10];

        DrawableName[0] = "ash";
        DrawableName[1] = "birch";
        DrawableName[2] = "cedar";
        DrawableName[3] = "cherrywood";
        DrawableName[4] = "fir";
        DrawableName[5] = "mahogany";
        DrawableName[6] = "maple";
        DrawableName[7] = "oak";
        DrawableName[8] = "poplar";
        DrawableName[9] = "redwood";

        for(int i = 0 ;i < 10;i++){

            res_id[i] = getResources().getIdentifier(DrawableName[i] , "drawable", getPackageName());

        }


        MyRecyclerViewData[] myListData = new MyRecyclerViewData[] {



                new MyRecyclerViewData (DrawableName[0], res_id[0]),
                new MyRecyclerViewData (DrawableName[1], res_id[1]),
                new MyRecyclerViewData (DrawableName[2], res_id[2]),
                new MyRecyclerViewData (DrawableName[3], res_id[3]),
                new MyRecyclerViewData (DrawableName[4], res_id[4]),
                new MyRecyclerViewData (DrawableName[5], res_id[5]),
                new MyRecyclerViewData (DrawableName[6], res_id[6]),
                new MyRecyclerViewData (DrawableName[7], res_id[7]),
                new MyRecyclerViewData (DrawableName[8], res_id[8]),
                new MyRecyclerViewData (DrawableName[9], res_id[9]),

        };

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        MyListAdapter adapter = new MyListAdapter(myListData);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);
    }
}